using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Windows.Forms;
using Microsoft.Win32;

namespace DesktopIconToggle
{
    public class Settings
    {
        public bool IconsHidden { get; set; } = false;
        public int ButtonX { get; set; } = -1;
        public int ButtonY { get; set; } = -1;
        public bool AutoStart { get; set; } = true;
        public bool AutoHideEnabled { get; set; } = false;
        public int AutoHideDelaySeconds { get; set; } = 5;
        public int DockSide { get; set; } = 0; // 0=Left, 1=Top (only these two are supported)
        public float DpiScale { get; set; } = 1.0f;
        public string MonitorId { get; set; } = "";
    }

    // Custom modern panel with rounded corners and DPI awareness
    public class ModernPanel : Panel
    {
        [System.ComponentModel.Browsable(false)]
        [System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Hidden)]
        public int BorderRadius { get; set; } = 8;
        
        [System.ComponentModel.Browsable(false)]
        [System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Hidden)]
        public Color BorderColor { get; set; } = Color.Gray;
        
        [System.ComponentModel.Browsable(false)]
        [System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Hidden)]
        public int BorderWidth { get; set; } = 0;

        public ModernPanel()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.DoubleBuffer | ControlStyles.ResizeRedraw, true);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            Rectangle rect = new Rectangle(0, 0, Width - 1, Height - 1);

            using (GraphicsPath path = GetRoundedRectPath(rect, BorderRadius))
            {
                using (SolidBrush brush = new SolidBrush(BackColor))
                {
                    g.FillPath(brush, path);
                }

                if (BorderWidth > 0)
                {
                    using (Pen pen = new Pen(BorderColor, BorderWidth))
                    {
                        g.DrawPath(pen, path);
                    }
                }
            }
        }

        private GraphicsPath GetRoundedRectPath(Rectangle rect, int radius)
        {
            GraphicsPath path = new GraphicsPath();

            if (radius <= 0)
            {
                path.AddRectangle(rect);
                return path;
            }

            int diameter = radius * 2;
            
            if (diameter > rect.Width) diameter = rect.Width;
            if (diameter > rect.Height) diameter = rect.Height;
            
            Size size = new Size(diameter, diameter);
            Rectangle arc = new Rectangle(rect.Location, size);

            path.AddArc(arc, 180, 90);

            arc.X = rect.Right - diameter;
            path.AddArc(arc, 270, 90);

            arc.Y = rect.Bottom - diameter;
            path.AddArc(arc, 0, 90);

            arc.X = rect.Left;
            path.AddArc(arc, 90, 90);

            path.CloseFigure();
            return path;
        }
    }

    // Custom modern button with hover effects and DPI scaling
    public class ModernButton : Button
    {
        [System.ComponentModel.Browsable(false)]
        [System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Hidden)]
        public int BorderRadius { get; set; } = 8;
        
        [System.ComponentModel.Browsable(false)]
        [System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Hidden)]
        public Color HoverColor { get; set; } = Color.LightGray;
        
        [System.ComponentModel.Browsable(false)]
        [System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Hidden)]
        public Color PressedColor { get; set; } = Color.Gray;

        private bool isHovered = false;
        private bool isPressed = false;

        public ModernButton()
        {
            FlatStyle = FlatStyle.Flat;
            FlatAppearance.BorderSize = 0;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.DoubleBuffer | ControlStyles.ResizeRedraw, true);
        }

        protected override void OnMouseEnter(EventArgs e)
        {
            isHovered = true;
            Invalidate();
            base.OnMouseEnter(e);
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            isHovered = false;
            Invalidate();
            base.OnMouseLeave(e);
        }

        protected override void OnMouseDown(MouseEventArgs mevent)
        {
            isPressed = true;
            Invalidate();
            base.OnMouseDown(mevent);
        }

        protected override void OnMouseUp(MouseEventArgs mevent)
        {
            isPressed = false;
            Invalidate();
            base.OnMouseUp(mevent);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            Rectangle rect = new Rectangle(0, 0, Width - 1, Height - 1);
            Color currentColor = BackColor;

            if (isPressed)
                currentColor = PressedColor;
            else if (isHovered)
                currentColor = HoverColor;

            using (GraphicsPath path = GetRoundedRectPath(rect, BorderRadius))
            {
                using (SolidBrush brush = new SolidBrush(currentColor))
                {
                    g.FillPath(brush, path);
                }

                if (isHovered && !isPressed)
                {
                    using (Pen glowPen = new Pen(Color.FromArgb(50, Color.White), 2))
                    {
                        g.DrawPath(glowPen, path);
                    }
                }
            }

            TextRenderer.DrawText(g, Text, Font, rect, ForeColor,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
        }

        private GraphicsPath GetRoundedRectPath(Rectangle rect, int radius)
        {
            GraphicsPath path = new GraphicsPath();

            if (radius <= 0)
            {
                path.AddRectangle(rect);
                return path;
            }

            int diameter = radius * 2;
            
            if (diameter > rect.Width) diameter = rect.Width;
            if (diameter > rect.Height) diameter = rect.Height;
            
            Size size = new Size(diameter, diameter);
            Rectangle arc = new Rectangle(rect.Location, size);

            path.AddArc(arc, 180, 90);

            arc.X = rect.Right - diameter;
            path.AddArc(arc, 270, 90);

            arc.Y = rect.Bottom - diameter;
            path.AddArc(arc, 0, 90);

            arc.X = rect.Left;
            path.AddArc(arc, 90, 90);

            path.CloseFigure();
            return path;
        }
    }

    public partial class ToggleButton : Form
    {
        // Windows API for desktop icon manipulation
        [DllImport("user32.dll")]
        private static extern IntPtr FindWindow(string? className, string? windowName);

        [DllImport("user32.dll")]
        private static extern IntPtr FindWindowEx(IntPtr parent, IntPtr childAfter, string? className, string? windowName);

        [DllImport("user32.dll")]
        private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        // DPI awareness API
        [DllImport("user32.dll")]
        private static extern IntPtr MonitorFromPoint(POINT pt, uint dwFlags);

        [DllImport("shcore.dll")]
        private static extern int GetDpiForMonitor(IntPtr hmonitor, int dpiType, out uint dpiX, out uint dpiY);

        // Taskbar hiding API
        [DllImport("user32.dll")]
        private static extern int FindWindowA(string lpClassName, string lpWindowName);

        [DllImport("user32.dll")]
        private static extern int ShowWindow(int hwnd, int nCmdShow);

        // Mouse tracking API
        [DllImport("user32.dll")]
        private static extern bool GetCursorPos(out POINT lpPoint);

        // API for detecting user input activity
        [DllImport("user32.dll")]
        private static extern bool GetLastInputInfo(ref LASTINPUTINFO plii);

        [StructLayout(LayoutKind.Sequential)]
        public struct POINT
        {
            public int X;
            public int Y;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct LASTINPUTINFO
        {
            public uint cbSize;
            public uint dwTime;
        }

        private const int SW_HIDE = 0;
        private const int SW_SHOW = 5;
        private const int MONITOR_DEFAULTTONEAREST = 2;
        private const int MDT_EFFECTIVE_DPI = 0;

        // Responsive design constants - optimized for better proportions
        private const int BASE_BUTTON_SIZE = 24;
        private const int BASE_BUTTON_LENGTH = 64;
        private const int BASE_MENU_WIDTH = 200; // Reduced from 280
        private const int BASE_MENU_HEIGHT = 120; // Reduced from 140
        private const int BASE_FONT_SIZE = 9;
        private const int MENU_MARGIN = 8; // Reduced margin

        // DPI-scaled dimensions
        private int ScaledButtonSize => (int)(BASE_BUTTON_SIZE * currentDpiScale);
        private int ScaledButtonLength => (int)(BASE_BUTTON_LENGTH * currentDpiScale);
        private int ScaledMenuWidth => (int)(BASE_MENU_WIDTH * currentDpiScale);
        private int ScaledMenuHeight => (int)(BASE_MENU_HEIGHT * currentDpiScale);
        private int ScaledMargin => (int)(MENU_MARGIN * currentDpiScale);
        private float ScaledFontSize => BASE_FONT_SIZE * currentDpiScale;

        // Modern color scheme
        private readonly Color PrimaryDark = Color.FromArgb(24, 24, 27);
        private readonly Color PrimaryLight = Color.FromArgb(39, 39, 42);
        private readonly Color AccentBlue = Color.FromArgb(59, 130, 246);
        private readonly Color AccentGreen = Color.FromArgb(34, 197, 94);
        private readonly Color AccentRed = Color.FromArgb(239, 68, 68);
        private readonly Color AccentOrange = Color.FromArgb(249, 115, 22);
        private readonly Color TextPrimary = Color.FromArgb(248, 250, 252);
        private readonly Color TextSecondary = Color.FromArgb(148, 163, 184);
        private readonly Color BorderColor = Color.FromArgb(63, 63, 70);

        // UI Elements
        private ModernPanel navButton = new ModernPanel();
        private ModernPanel expandedPanel = new ModernPanel();
        private ModernButton autoButton = new ModernButton();
        private ModernButton showButton = new ModernButton();
        private ModernButton exitButton = new ModernButton();

        private NotifyIcon trayIcon = new NotifyIcon();

        // State variables
        private Settings settings = new Settings();
        private string configPath = "";
        private bool isExpanded = false;
        private bool isDragging = false;
        private Point dragOffset;
        private float currentDpiScale = 1.0f;
        private Screen? currentScreen;

        // Auto-hide functionality
        private System.Windows.Forms.Timer userActivityTimer = new System.Windows.Forms.Timer();
        private System.Windows.Forms.Timer autoHideTimer = new System.Windows.Forms.Timer();
        private System.Windows.Forms.Timer collapseTimer = new System.Windows.Forms.Timer();
        private System.Windows.Forms.Timer hoverTimer = new System.Windows.Forms.Timer();
        private System.Windows.Forms.Timer dpiCheckTimer = new System.Windows.Forms.Timer();
        private uint lastInputTime = 0;

        public ToggleButton()
        {
            // Initialize currentScreen first to avoid nullable warnings
            currentScreen = Screen.PrimaryScreen ?? Screen.AllScreens[0];
            
            // Enable DPI awareness
            SetProcessDpiAwareness();
            
            InitializeApplication();
            LoadSettings();
            SetupTrayIcon();
            SetupTimers();
            SetupUI();
            ApplyCurrentState();

            // Auto-open dashboard when app first loads
            this.Shown += (_, __) => OpenDashboard(null, EventArgs.Empty);
        }

        [DllImport("shcore.dll")]
        private static extern int SetProcessDpiAwareness(int awareness);

        private void SetProcessDpiAwareness()
        {
            try
            {
                SetProcessDpiAwareness(2);
            }
            catch
            {
                Application.SetHighDpiMode(HighDpiMode.PerMonitorV2);
            }
        }

        private void InitializeApplication()
        {
            this.Text = "Desktop Toggle";
            this.FormBorderStyle = FormBorderStyle.None;
            this.TopMost = false;
            this.ShowInTaskbar = false;
            this.StartPosition = FormStartPosition.Manual;
            this.BackColor = Color.Magenta;
            this.TransparencyKey = Color.Magenta;
            this.Size = new Size(1, 1);
            this.MinimumSize = new Size(1, 1);
            this.Location = new Point(-32000, -32000);
            this.Opacity = 0;

            this.SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.DoubleBuffer, true);

            UpdateDpiScale();
        }

        private void UpdateDpiScale()
        {
            if (currentScreen == null) 
                currentScreen = Screen.FromPoint(this.Location.IsEmpty ? new Point(100, 100) : this.Location);
            
            try
            {
                POINT point = new POINT { X = currentScreen.Bounds.X + 100, Y = currentScreen.Bounds.Y + 100 };
                IntPtr monitor = MonitorFromPoint(point, MONITOR_DEFAULTTONEAREST);
                
                if (monitor != IntPtr.Zero)
                {
                    if (GetDpiForMonitor(monitor, MDT_EFFECTIVE_DPI, out uint dpiX, out uint dpiY) == 0)
                    {
                        currentDpiScale = dpiX / 96.0f;
                        settings.DpiScale = currentDpiScale;
                    }
                }
            }
            catch
            {
                using (Graphics g = CreateGraphics())
                {
                    currentDpiScale = g.DpiX / 96.0f;
                }
            }
        }

        private void SetupUI()
        {
            UpdateFormAndButtonSize();

            // Navigation button hidden — dashboard opens automatically
            navButton.Visible = false;
            navButton.Size = new Size(1, 1);

            // Dragging for repositioning - enable even when expanded
            navButton.MouseDown += StartDrag;
            navButton.MouseMove += DragButton;
            navButton.MouseUp += EndDrag;
            this.MouseDown += StartDrag;
            this.MouseMove += DragButton;
            this.MouseUp += EndDrag;

            // Expanded panel hidden — nav button opens dashboard directly
            expandedPanel.Visible = false;

            this.Controls.Add(navButton);
            this.Controls.Add(expandedPanel);

            expandedPanel.MouseLeave += StartCollapseTimer;
            this.MouseLeave += StartCollapseTimer;
        }

        private void PositionNavButton()
        {
            // Position nav button properly based on dock side and form state
            if (isExpanded)
            {
                // When expanded, keep nav button in a fixed, visible position
                switch (settings.DockSide)
                {
                    case 0: // Left edge - button should be on left side, but always visible
                        navButton.Location = new Point(2, Math.Max(2, Math.Min(this.Height - navButton.Height - 2, expandedPanel.Location.Y + (expandedPanel.Height - navButton.Height) / 2)));
                        break;
                    case 1: // Top edge - button should be on top, but always visible
                        navButton.Location = new Point(Math.Max(2, Math.Min(this.Width - navButton.Width - 2, expandedPanel.Location.X + (expandedPanel.Width - navButton.Width) / 2)), 2);
                        break;
                    default:
                        navButton.Location = new Point(2, Math.Max(2, Math.Min(this.Height - navButton.Height - 2, expandedPanel.Location.Y + (expandedPanel.Height - navButton.Height) / 2)));
                        break;
                }
            }
            else
            {
                // When collapsed, center in the small form
                navButton.Location = new Point(
                    Math.Max(2, (this.Width - navButton.Width) / 2),
                    Math.Max(2, (this.Height - navButton.Height) / 2)
                );
            }
        }

        private void UpdateFormAndButtonSize()
        {
            switch (settings.DockSide)
            {
                case 0: // Left edge
                    this.Size = new Size(ScaledButtonSize, ScaledButtonLength);
                    navButton.Size = new Size(ScaledButtonSize - 4, ScaledButtonLength - 4);
                    break;
                case 1: // Top edge
                    this.Size = new Size(ScaledButtonLength, ScaledButtonSize);
                    navButton.Size = new Size(ScaledButtonLength - 4, ScaledButtonSize - 4);
                    break;
                default:
                    settings.DockSide = 0;
                    this.Size = new Size(ScaledButtonSize, ScaledButtonLength);
                    navButton.Size = new Size(ScaledButtonSize - 4, ScaledButtonLength - 4);
                    break;
            }

            expandedPanel.Size = new Size(ScaledMenuWidth, ScaledMenuHeight);
            if (navButton != null) PositionNavButton();
        }

        private void OnNavButtonHover(object? sender, EventArgs e)
        {
            navButton.BackColor = PrimaryLight;
            hoverTimer.Stop();
            hoverTimer.Start();
        }

        private void OnNavButtonLeave(object? sender, EventArgs e)
        {
            navButton.BackColor = PrimaryDark;
            hoverTimer.Stop();
        }

        private void SetupModernButton(ModernButton btn, string text, int x, int y, int width, int height, Color color, string tooltip, Font font)
        {
            btn.Size = new Size(width, height);
            btn.Location = new Point(x, y);
            btn.Text = text;
            btn.BackColor = color;
            btn.ForeColor = TextPrimary;
            btn.BorderRadius = (int)(8 * currentDpiScale);
            btn.Font = font;
            btn.HoverColor = LightenColor(color, 0.1f);
            btn.PressedColor = DarkenColor(color, 0.1f);
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;

            ToolTip toolTip = new ToolTip();
            toolTip.SetToolTip(btn, tooltip);

            btn.MouseEnter += (s, e) =>
            {
                collapseTimer?.Stop();
            };
        }

        private Color LightenColor(Color color, float amount)
        {
            return Color.FromArgb(color.A,
                Math.Min(255, (int)(color.R + (255 - color.R) * amount)),
                Math.Min(255, (int)(color.G + (255 - color.G) * amount)),
                Math.Min(255, (int)(color.B + (255 - color.B) * amount)));
        }

        private Color DarkenColor(Color color, float amount)
        {
            return Color.FromArgb(color.A,
                Math.Max(0, (int)(color.R * (1 - amount))),
                Math.Max(0, (int)(color.G * (1 - amount))),
                Math.Max(0, (int)(color.B * (1 - amount))));
        }

        private void DrawNavButton(object? sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            // Try to draw arrows first
            bool arrowsDrawn = false;
            try
            {
                // Draw main arrow with pure white color
                using (Brush brush = new SolidBrush(Color.White))
                {
                    Point[] arrow = GetModernArrowPoints();
                    if (arrow.Length > 0)
                    {
                        g.FillPolygon(brush, arrow);
                        arrowsDrawn = true;
                    }
                }

                // Add a subtle blue glow/outline for better visibility
                using (Pen glowPen = new Pen(Color.FromArgb(80, AccentBlue), Math.Max(1, (int)(1.5f * currentDpiScale))))
                {
                    Point[] arrow = GetModernArrowPoints();
                    if (arrow.Length > 0)
                    {
                        g.DrawPolygon(glowPen, arrow);
                    }
                }

                // Add a secondary smaller arrow with semi-transparent white
                using (Brush secondaryBrush = new SolidBrush(Color.FromArgb(150, Color.White)))
                {
                    Point[] secondaryArrow = GetSecondaryArrowPoints();
                    if (secondaryArrow.Length > 0)
                    {
                        g.FillPolygon(secondaryBrush, secondaryArrow);
                    }
                }
            }
            catch
            {
                arrowsDrawn = false;
            }

            // Fallback: If arrows failed to draw, show text instead
            if (!arrowsDrawn)
            {
                string buttonText = settings.DockSide == 0 ? ">" : "v";
                using (Font textFont = new Font("Segoe UI", Math.Max(8, ScaledFontSize), FontStyle.Bold))
                {
                    using (Brush textBrush = new SolidBrush(Color.White))
                    {
                        StringFormat format = new StringFormat();
                        format.Alignment = StringAlignment.Center;
                        format.LineAlignment = StringAlignment.Center;
                        
                        Rectangle textRect = new Rectangle(0, 0, navButton.Width, navButton.Height);
                        g.DrawString(buttonText, textFont, textBrush, textRect, format);
                    }
                }
            }
        }

        private Point[] GetModernArrowPoints()
        {
            int centerX = navButton.Width / 2;
            int centerY = navButton.Height / 2;
            int size = Math.Max(6, (int)(8 * currentDpiScale)); // Increased size for better visibility

            switch (settings.DockSide)
            {
                case 0: // Left edge - arrow points right
                    return new Point[] {
                        new Point(centerX - size, centerY - size),
                        new Point(centerX + size, centerY),
                        new Point(centerX - size, centerY + size)
                    };
                case 1: // Top edge - arrow points down
                    return new Point[] {
                        new Point(centerX - size, centerY - size),
                        new Point(centerX, centerY + size),
                        new Point(centerX + size, centerY - size)
                    };
                default:
                    return new Point[] {
                        new Point(centerX - size, centerY - size),
                        new Point(centerX + size, centerY),
                        new Point(centerX - size, centerY + size)
                    };
            }
        }

        private Point[] GetSecondaryArrowPoints()
        {
            int centerX = navButton.Width / 2;
            int centerY = navButton.Height / 2;
            int size = Math.Max(3, (int)(4 * currentDpiScale)); // Smaller secondary arrow
            int offset = Math.Max(8, (int)(12 * currentDpiScale)); // Distance from main arrow

            switch (settings.DockSide)
            {
                case 0: // Left edge - secondary arrow points right, positioned to the left
                    centerX -= offset;
                    return new Point[] {
                        new Point(centerX - size, centerY - size),
                        new Point(centerX + size, centerY),
                        new Point(centerX - size, centerY + size)
                    };
                case 1: // Top edge - secondary arrow points down, positioned above
                    centerY -= offset;
                    return new Point[] {
                        new Point(centerX - size, centerY - size),
                        new Point(centerX, centerY + size),
                        new Point(centerX + size, centerY - size)
                    };
                default:
                    centerX -= offset;
                    return new Point[] {
                        new Point(centerX - size, centerY - size),
                        new Point(centerX + size, centerY),
                        new Point(centerX - size, centerY + size)
                    };
            }
        }

        private void ToggleExpand(object? sender, EventArgs e)
        {
            isExpanded = !isExpanded;
            collapseTimer.Stop();
            hoverTimer.Stop();

            if (isExpanded)
            {
                ExpandPanel();
            }
            else
            {
                CollapsePanel();
            }
        }

        private DashboardForm? _dashboard;

        private void OpenDashboard(object? sender, EventArgs e)
        {
            if (isExpanded) CollapsePanel();

            if (_dashboard != null && !_dashboard.IsDisposed)
            {
                _dashboard.BringToFront();
                _dashboard.Focus();
                return;
            }

            _dashboard = new DashboardForm(
                settings,
                SaveSettings,
                ShowDesktopIcons,
                HideDesktopIcons,
                ShowTaskbar,
                HideTaskbar,
                () => true,
                StartAutoHideMode,
                StopAutoHideMode,
                () => ClickExit(null, EventArgs.Empty)
            );
            _dashboard.FormClosed += (s, args) => _dashboard = null;
            _dashboard.Show();
        }

        private void ExpandPanel()
        {
            float oldDpi = currentDpiScale;
            UpdateDpiScale();
            
            if (Math.Abs(oldDpi - currentDpiScale) > 0.1f)
            {
                RecreateUIForDpiChange();
            }

            expandedPanel.Visible = true;
            PositionExpandedPanelSmart();
            UpdateButtonStates();
            ResizeFormForExpansion();
        }

        private void RecreateUIForDpiChange()
        {
            this.Controls.Clear();
            expandedPanel.Controls.Clear();
            
            SetupUI();
        }

        private void ResizeFormForExpansion()
        {
            var positionData = CalculateSmartPosition();
            
            this.Size = positionData.FormSize;
            this.Location = positionData.FormLocation;
        }

        private void CollapsePanel()
        {
            expandedPanel.Visible = false;
            UpdateFormAndButtonSize();
            PositionAtEdge();
            isExpanded = false;
        }

        private struct SmartPositionData
        {
            public Point PanelLocation;
            public Size FormSize;
            public Point FormLocation;
        }

        private SmartPositionData CalculateSmartPosition()
        {
            Rectangle screen = (currentScreen ?? Screen.PrimaryScreen)?.WorkingArea ?? Rectangle.Empty;
            Point currentFormLocation = this.Location;
            
            SmartPositionData result = new SmartPositionData();
            
            switch (settings.DockSide)
            {
                case 0: // Left edge
                    result = CalculateLeftEdgePosition(screen, currentFormLocation);
                    break;
                case 1: // Top edge
                    result = CalculateTopEdgePosition(screen, currentFormLocation);
                    break;
                default:
                    settings.DockSide = 0;
                    result = CalculateLeftEdgePosition(screen, currentFormLocation);
                    break;
            }
            
            return result;
        }

        private SmartPositionData CalculateLeftEdgePosition(Rectangle screen, Point currentFormLocation)
        {
            SmartPositionData result = new SmartPositionData();
            
            // Default: panel to the right of the button, with button centered in panel height
            int panelX = ScaledButtonSize;
            int formWidth = ScaledButtonSize + ScaledMenuWidth + ScaledMargin;
            
            // Calculate button centering in panel
            int buttonCenterOffset = (ScaledMenuHeight - ScaledButtonLength) / 2;
            int idealButtonY = currentFormLocation.Y;
            int idealPanelY = Math.Max(ScaledMargin, buttonCenterOffset);
            
            // Check if menu would go off right edge
            if (currentFormLocation.X + formWidth > screen.Right - ScaledMargin)
            {
                // Position panel to the left (overlay mode)
                panelX = -(ScaledMenuWidth - ScaledButtonSize);
                formWidth = ScaledMenuWidth + ScaledMargin;
                result.FormLocation = new Point(Math.Max(screen.Left, currentFormLocation.X - (ScaledMenuWidth - ScaledButtonSize)), idealButtonY);
            }
            else
            {
                result.FormLocation = new Point(currentFormLocation.X, idealButtonY);
            }
            
            int formHeight = Math.Max(ScaledButtonLength, ScaledMenuHeight + ScaledMargin * 2);
            
            // Adjust for screen boundaries - move the entire form, not just the panel
            if (result.FormLocation.Y + formHeight > screen.Bottom - ScaledMargin)
            {
                int adjustment = (result.FormLocation.Y + formHeight) - (screen.Bottom - ScaledMargin);
                result.FormLocation = new Point(result.FormLocation.X, Math.Max(screen.Top, result.FormLocation.Y - adjustment));
                
                // Recalculate panel position relative to button
                int buttonRelativeY = idealButtonY - result.FormLocation.Y;
                idealPanelY = Math.Max(ScaledMargin, buttonRelativeY - buttonCenterOffset);
            }
            
            if (result.FormLocation.Y < screen.Top + ScaledMargin)
            {
                int adjustment = (screen.Top + ScaledMargin) - result.FormLocation.Y;
                result.FormLocation = new Point(result.FormLocation.X, screen.Top + ScaledMargin);
                
                // Recalculate panel position relative to button
                int buttonRelativeY = idealButtonY - result.FormLocation.Y;
                idealPanelY = Math.Max(ScaledMargin, buttonRelativeY - buttonCenterOffset);
            }
            
            // Ensure panel stays within form bounds
            idealPanelY = Math.Max(ScaledMargin, Math.Min(idealPanelY, formHeight - ScaledMenuHeight - ScaledMargin));
            
            result.PanelLocation = new Point(panelX, idealPanelY);
            result.FormSize = new Size(formWidth, formHeight);
            
            return result;
        }

        private SmartPositionData CalculateTopEdgePosition(Rectangle screen, Point currentFormLocation)
        {
            SmartPositionData result = new SmartPositionData();
            
            // Default: panel below the button, with button centered in panel width
            int panelY = ScaledButtonSize;
            int formHeight = ScaledButtonSize + ScaledMenuHeight + ScaledMargin;
            
            // Calculate button centering in panel
            int buttonCenterOffset = (ScaledMenuWidth - ScaledButtonLength) / 2;
            int idealButtonX = currentFormLocation.X;
            int idealPanelX = Math.Max(ScaledMargin, buttonCenterOffset);
            
            // Check if menu would go off bottom edge
            if (currentFormLocation.Y + formHeight > screen.Bottom - ScaledMargin)
            {
                // Position panel above (overlay mode)
                panelY = -(ScaledMenuHeight - ScaledButtonSize);
                formHeight = ScaledMenuHeight + ScaledMargin;
                result.FormLocation = new Point(idealButtonX, Math.Max(screen.Top, currentFormLocation.Y - (ScaledMenuHeight - ScaledButtonSize)));
            }
            else
            {
                result.FormLocation = new Point(idealButtonX, currentFormLocation.Y);
            }
            
            int formWidth = Math.Max(ScaledButtonLength, ScaledMenuWidth + ScaledMargin * 2);
            
            // Adjust for screen boundaries - move the entire form, not just the panel
            if (result.FormLocation.X + formWidth > screen.Right - ScaledMargin)
            {
                int adjustment = (result.FormLocation.X + formWidth) - (screen.Right - ScaledMargin);
                result.FormLocation = new Point(Math.Max(screen.Left, result.FormLocation.X - adjustment), result.FormLocation.Y);
                
                // Recalculate panel position relative to button
                int buttonRelativeX = idealButtonX - result.FormLocation.X;
                idealPanelX = Math.Max(ScaledMargin, buttonRelativeX - buttonCenterOffset);
            }
            
            if (result.FormLocation.X < screen.Left + ScaledMargin)
            {
                int adjustment = (screen.Left + ScaledMargin) - result.FormLocation.X;
                result.FormLocation = new Point(screen.Left + ScaledMargin, result.FormLocation.Y);
                
                // Recalculate panel position relative to button
                int buttonRelativeX = idealButtonX - result.FormLocation.X;
                idealPanelX = Math.Max(ScaledMargin, buttonRelativeX - buttonCenterOffset);
            }
            
            // Ensure panel stays within form bounds
            idealPanelX = Math.Max(ScaledMargin, Math.Min(idealPanelX, formWidth - ScaledMenuWidth - ScaledMargin));
            
            result.PanelLocation = new Point(idealPanelX, panelY);
            result.FormSize = new Size(formWidth, formHeight);
            
            return result;
        }

        private void PositionExpandedPanelSmart()
        {
            var positionData = CalculateSmartPosition();
            expandedPanel.Location = positionData.PanelLocation;
        }

        private void PositionAtEdge()
        {
            currentScreen = Screen.FromPoint(new Point(settings.ButtonX, settings.ButtonY));
            Rectangle screen = currentScreen?.WorkingArea ?? Rectangle.Empty;

            switch (settings.DockSide)
            {
                case 0: // Left edge
                    this.Location = new Point(screen.Left, Math.Max(screen.Top, Math.Min(settings.ButtonY, screen.Bottom - this.Height)));
                    break;
                case 1: // Top edge
                    this.Location = new Point(Math.Max(screen.Left, Math.Min(settings.ButtonX, screen.Right - this.Width)), screen.Top);
                    break;
                default:
                    settings.DockSide = 0;
                    this.Location = new Point(screen.Left, Math.Max(screen.Top, Math.Min(settings.ButtonY, screen.Bottom - this.Height)));
                    break;
            }

            settings.ButtonX = this.Location.X;
            settings.ButtonY = this.Location.Y;
        }

        private void StartCollapseTimer(object? sender, EventArgs e)
        {
            if (isExpanded)
            {
                collapseTimer.Stop();
                collapseTimer.Start();
            }
        }

        private void UpdateButtonStates()
        {
            // Expanded panel buttons removed; dashboard handles all controls
        }

        // Button click handlers
        private void StartAutoHideMode()
        {
            settings.AutoHideEnabled = true;
            settings.IconsHidden = false;
            ShowDesktopIcons();
            ShowTaskbar();
            userActivityTimer.Start();
            ResetAutoHideTimer();
            UpdateButtonStates();
            SaveSettings();
        }

        private void StopAutoHideMode()
        {
            settings.AutoHideEnabled = false;
            userActivityTimer.Stop();
            autoHideTimer.Stop();
            settings.IconsHidden = false;
            ShowDesktopIcons();
            ShowTaskbar();
            UpdateButtonStates();
            SaveSettings();
        }

        private void ClickAuto(object? sender, EventArgs e)
        {
            if (!settings.AutoHideEnabled) StartAutoHideMode();
            else StopAutoHideMode();
            // UpdateButtonStates and SaveSettings already called inside helpers
        }

        private void ClickShow(object? sender, EventArgs e)
        {
            settings.IconsHidden = !settings.IconsHidden;

            if (settings.IconsHidden)
            {
                HideDesktopIcons();
                HideTaskbar();
            }
            else
            {
                ShowDesktopIcons();
                ShowTaskbar();
            }

            UpdateButtonStates();
            SaveSettings();
        }

        private void ClickDock(object? sender, EventArgs e)
        {
            // This method is no longer used since dock button was removed
        }

        private void ClickExit(object? sender, EventArgs e)
        {
            if (settings.IconsHidden)
            {
                ShowDesktopIcons();
                ShowTaskbar();
            }
            trayIcon.Visible = false;
            Application.Exit();
        }

        private void SetupTimers()
        {
            userActivityTimer.Interval = 1000;
            userActivityTimer.Tick += CheckUserActivity;

            autoHideTimer.Tick += OnAutoHideTimeout;

            collapseTimer.Interval = 2000;
            collapseTimer.Tick += (s, e) => { CollapsePanel(); collapseTimer.Stop(); };

            hoverTimer.Interval = 500;
            hoverTimer.Tick += (s, e) =>
            {
                if (!isExpanded) ExpandPanel();
                hoverTimer.Stop();
            };

            dpiCheckTimer.Interval = 5000;
            dpiCheckTimer.Tick += CheckDpiChange;
            dpiCheckTimer.Start();

            LASTINPUTINFO lii = new LASTINPUTINFO();
            lii.cbSize = (uint)Marshal.SizeOf(lii);
            if (GetLastInputInfo(ref lii))
            {
                lastInputTime = lii.dwTime;
            }
        }

        private void CheckDpiChange(object? sender, EventArgs e)
        {
            float oldDpi = currentDpiScale;
            Screen? newScreen = Screen.FromPoint(this.Location);
            
            if (newScreen != null && newScreen != currentScreen)
            {
                currentScreen = newScreen;
                UpdateDpiScale();
                
                if (Math.Abs(oldDpi - currentDpiScale) > 0.1f)
                {
                    if (isExpanded)
                    {
                        CollapsePanel();
                    }
                    
                    RecreateUIForDpiChange();
                    SaveSettings();
                }
            }
        }

        private void CheckUserActivity(object? sender, EventArgs e)
        {
            if (!settings.AutoHideEnabled) return;

            LASTINPUTINFO lii = new LASTINPUTINFO();
            lii.cbSize = (uint)Marshal.SizeOf(lii);
            
            if (GetLastInputInfo(ref lii))
            {
                uint currentInputTime = lii.dwTime;
                
                if (currentInputTime != lastInputTime)
                {
                    lastInputTime = currentInputTime;
                    
                    if (settings.IconsHidden && settings.AutoHideEnabled)
                    {
                        ShowDesktopIcons();
                        ShowTaskbar();
                        settings.IconsHidden = false;
                        UpdateButtonStates();
                        SaveSettings();
                    }
                    
                    ResetAutoHideTimer();
                }
            }
        }

        private void ResetAutoHideTimer()
        {
            autoHideTimer.Stop();
            autoHideTimer.Interval = settings.AutoHideDelaySeconds * 1000;
            autoHideTimer.Start();
        }

        private void OnAutoHideTimeout(object? sender, EventArgs e)
        {
            if (settings.AutoHideEnabled && !settings.IconsHidden)
            {
                HideDesktopIcons();
                HideTaskbar();
                settings.IconsHidden = true;
                UpdateButtonStates();
                SaveSettings();
            }
            autoHideTimer.Stop();
        }

        // Enhanced dragging functionality with full screen movement - works even when expanded
        private void StartDrag(object? sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isDragging = true;
                // Calculate offset based on which control was clicked
                if (sender == navButton)
                {
                    dragOffset = e.Location;
                }
                else
                {
                    // If dragging from form itself, use form coordinates
                    dragOffset = e.Location;
                }
            }
        }

        private void DragButton(object? sender, MouseEventArgs e)
        {
            if (isDragging)
            {
                Point newPos;
                
                if (sender == navButton)
                {
                    // Calculate new position based on nav button drag
                    newPos = new Point(
                        this.Location.X + e.X - dragOffset.X, 
                        this.Location.Y + e.Y - dragOffset.Y
                    );
                }
                else
                {
                    // Calculate new position based on form drag
                    newPos = new Point(
                        this.Location.X + e.X - dragOffset.X,
                        this.Location.Y + e.Y - dragOffset.Y
                    );
                }
                
                Screen? targetScreen = Screen.FromPoint(newPos);
                Rectangle screen = targetScreen?.WorkingArea ?? Rectangle.Empty;
                
                int snapDistance = (int)(50 * currentDpiScale);
                int newDockSide = settings.DockSide;

                // Allow movement anywhere on screen - no constraints
                newPos.X = Math.Max(screen.Left, Math.Min(newPos.X, screen.Right - this.Width));
                newPos.Y = Math.Max(screen.Top, Math.Min(newPos.Y, screen.Bottom - this.Height));

                // Only snap to edges when collapsed
                if (!isExpanded)
                {
                    // Determine dock side based on proximity to edges
                    int distanceToLeft = Math.Abs(newPos.X - screen.Left);
                    int distanceToTop = Math.Abs(newPos.Y - screen.Top);
                    int distanceToRight = Math.Abs(newPos.X - (screen.Right - this.Width));
                    int distanceToBottom = Math.Abs(newPos.Y - (screen.Bottom - this.Height));

                    // Find the closest edge
                    int minDistance = Math.Min(Math.Min(distanceToLeft, distanceToTop), Math.Min(distanceToRight, distanceToBottom));

                    if (minDistance < snapDistance)
                    {
                        // Snap to closest edge, but only support left and top docking
                        if (minDistance == distanceToLeft)
                            newDockSide = 0; // Left edge
                        else if (minDistance == distanceToTop)
                            newDockSide = 1; // Top edge
                        else if (minDistance == distanceToRight)
                            newDockSide = 0; // Snap to left instead of right
                        else if (minDistance == distanceToBottom)
                            newDockSide = 1; // Snap to top instead of bottom
                    }
                }

                settings.ButtonX = newPos.X;
                settings.ButtonY = newPos.Y;
                
                // Update location directly
                this.Location = newPos;
                
                // Handle dock side changes
                if (newDockSide != settings.DockSide || targetScreen != currentScreen)
                {
                    settings.DockSide = newDockSide;
                    currentScreen = targetScreen;
                    UpdateDpiScale();
                    
                    if (isExpanded)
                    {
                        // Collapse first, then update, then re-expand to avoid positioning issues
                        bool wasExpanded = isExpanded;
                        CollapsePanel();
                        UpdateFormAndButtonSize();
                        if (wasExpanded)
                        {
                            ExpandPanel();
                        }
                    }
                    else
                    {
                        UpdateFormAndButtonSize();
                        PositionAtEdge();
                    }
                    navButton.Invalidate();
                }
                else
                {
                    if (isExpanded)
                    {
                        // When expanded, just reposition the panel and nav button
                        PositionExpandedPanelSmart();
                        PositionNavButton();
                    }
                    else
                    {
                        // When collapsed, snap to edge
                        PositionAtEdge();
                    }
                }
            }
        }

        private void EndDrag(object? sender, MouseEventArgs e)
        {
            if (isDragging)
            {
                isDragging = false;
                SaveSettings();
            }
        }

        // Desktop manipulation methods
        private void HideDesktopIcons()
        {
            IntPtr desktopHandle = FindDesktopIconWindow();
            if (desktopHandle != IntPtr.Zero)
            {
                ShowWindow(desktopHandle, SW_HIDE);
            }
        }

        private void ShowDesktopIcons()
        {
            IntPtr desktopHandle = FindDesktopIconWindow();
            if (desktopHandle != IntPtr.Zero)
            {
                ShowWindow(desktopHandle, SW_SHOW);
            }
        }

        private void HideTaskbar()
        {
            try
            {
                int hWnd = FindWindowA("Shell_TrayWnd", "");
                ShowWindow(hWnd, SW_HIDE);
            }
            catch { }
        }

        private void ShowTaskbar()
        {
            try
            {
                int hWnd = FindWindowA("Shell_TrayWnd", "");
                ShowWindow(hWnd, SW_SHOW);
            }
            catch { }
        }

        private IntPtr FindDesktopIconWindow()
        {
            IntPtr progman = FindWindow("Progman", "Program Manager");
            if (progman != IntPtr.Zero)
            {
                IntPtr defView = FindWindowEx(progman, IntPtr.Zero, "SHELLDLL_DefView", "");
                if (defView != IntPtr.Zero)
                {
                    IntPtr listView = FindWindowEx(defView, IntPtr.Zero, "SysListView32", "FolderView");
                    if (listView != IntPtr.Zero)
                        return listView;
                }
            }

            IntPtr workerW = IntPtr.Zero;
            do
            {
                workerW = FindWindowEx(IntPtr.Zero, workerW, "WorkerW", "");
                if (workerW != IntPtr.Zero)
                {
                    IntPtr shellDll = FindWindowEx(workerW, IntPtr.Zero, "SHELLDLL_DefView", "");
                    if (shellDll != IntPtr.Zero)
                    {
                        IntPtr listView = FindWindowEx(shellDll, IntPtr.Zero, "SysListView32", "FolderView");
                        if (listView != IntPtr.Zero)
                            return listView;
                    }
                }
            } while (workerW != IntPtr.Zero);

            return IntPtr.Zero;
        }

        private void SetupTrayIcon()
        {
            trayIcon = new NotifyIcon
            {
                Text = "Desktop Toggle",
                Visible = true
            };

            int iconSize = (int)(16 * currentDpiScale);
            Bitmap iconBitmap = new Bitmap(iconSize, iconSize);
            using (Graphics g = Graphics.FromImage(iconBitmap))
            {
                g.Clear(Color.Transparent);
                g.SmoothingMode = SmoothingMode.AntiAlias;
                
                int outerSize = (int)(12 * currentDpiScale);
                int innerSize = (int)(6 * currentDpiScale);
                int offset = (iconSize - outerSize) / 2;
                int innerOffset = (iconSize - innerSize) / 2;
                
                using (Brush brush = new SolidBrush(AccentBlue))
                {
                    g.FillEllipse(brush, offset, offset, outerSize, outerSize);
                }
                using (Brush innerBrush = new SolidBrush(Color.White))
                {
                    g.FillEllipse(innerBrush, innerOffset, innerOffset, innerSize, innerSize);
                }
            }
            trayIcon.Icon = Icon.FromHandle(iconBitmap.GetHicon());

            ContextMenuStrip trayMenu = new ContextMenuStrip();
            trayMenu.Items.Add("Open Dashboard", null, (s, e) => OpenDashboard(s, e));
            trayMenu.Items.Add("Show/Hide Desktop", null, (s, e) => ClickShow(s, e));
            trayMenu.Items.Add("Toggle Auto Mode", null, (s, e) => ClickAuto(s, e));
            trayMenu.Items.Add("-");
            trayMenu.Items.Add("Exit", null, (s, e) => ClickExit(s, e));
            trayIcon.ContextMenuStrip = trayMenu;

            trayIcon.DoubleClick += (s, e) => OpenDashboard(s, e);
        }

        private void ApplyCurrentState()
        {
            if (settings.ButtonX < 0 || settings.ButtonY < 0)
            {
                currentScreen = Screen.PrimaryScreen ?? Screen.AllScreens[0];
                settings.ButtonX = currentScreen.WorkingArea.Left;
                settings.ButtonY = currentScreen.WorkingArea.Top + 100;
            }

            PositionAtEdge();

            settings.IconsHidden = false;
            settings.AutoHideEnabled = false;
            ShowDesktopIcons();
            ShowTaskbar();
        }

        private void LoadSettings()
        {
            configPath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "DesktopIconToggle",
                "settings.json");

            try
            {
                if (File.Exists(configPath))
                {
                    string json = File.ReadAllText(configPath);
                    var loadedSettings = JsonSerializer.Deserialize<Settings>(json);
                    if (loadedSettings != null)
                    {
                        settings = loadedSettings;
                        currentDpiScale = settings.DpiScale > 0 ? settings.DpiScale : 1.0f;
                    }
                }
                else
                {
                    SaveSettings();
                }
            }
            catch
            {
                settings = new Settings();
            }
        }

        private void SaveSettings()
        {
            try
            {
                settings.DpiScale = currentDpiScale;
                string? directoryPath = Path.GetDirectoryName(configPath);
                if (!string.IsNullOrEmpty(directoryPath))
                {
                    Directory.CreateDirectory(directoryPath);
                }
                string json = JsonSerializer.Serialize(settings, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(configPath, json);
            }
            catch { }
        }

        protected override void SetBoundsCore(int x, int y, int width, int height, BoundsSpecified specified)
        {
            if (width < ScaledButtonSize) width = ScaledButtonSize;
            if (height < ScaledButtonSize) height = ScaledButtonSize;
            
            base.SetBoundsCore(x, y, width, height, specified);
        }

        protected override void WndProc(ref Message m)
        {
            const int WM_DPICHANGED = 0x02E0;
            const int WM_DISPLAYCHANGE = 0x007E;

            if (m.Msg == WM_DPICHANGED || m.Msg == WM_DISPLAYCHANGE)
            {
                if (!isExpanded)
                {
                    UpdateDpiScale();
                    RecreateUIForDpiChange();
                    SaveSettings();
                }
            }

            base.WndProc(ref m);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (settings?.IconsHidden == true)
                {
                    ShowDesktopIcons();
                    ShowTaskbar();
                }
                autoHideTimer?.Dispose();
                userActivityTimer?.Dispose();
                collapseTimer?.Dispose();
                hoverTimer?.Dispose();
                dpiCheckTimer?.Dispose();
                trayIcon?.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}