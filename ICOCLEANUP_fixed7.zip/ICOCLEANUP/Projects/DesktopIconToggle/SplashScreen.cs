using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace DesktopIconToggle
{
    public class SplashScreen : Form
    {
        private System.Windows.Forms.Timer animTimer  = new System.Windows.Forms.Timer();
        private System.Windows.Forms.Timer closeTimer = new System.Windows.Forms.Timer();
        private System.Windows.Forms.Timer fadeTimer  = new System.Windows.Forms.Timer();
        private float progress    = 0f;
        private int   animStep    = 0;
        private float ringScale   = 0.3f;
        private float logoAlpha   = 0f;
        private float byLineAlpha = 0f;
        private bool  isClosing   = false;

        private readonly Color BgColor     = Color.FromArgb(13, 13, 13);
        private readonly Color OrangeColor = Color.FromArgb(249, 115, 22);
        private readonly Color YellowColor = Color.FromArgb(251, 191, 36);
        private readonly Color WhiteColor  = Color.FromArgb(245, 245, 245);
        private readonly Color MutedColor  = Color.FromArgb(107, 107, 107);
        private readonly Color BorderColor = Color.FromArgb(42, 42, 42);

        public SplashScreen()
        {
            this.FormBorderStyle = FormBorderStyle.None;
            this.StartPosition   = FormStartPosition.CenterScreen;
            this.Size            = new Size(500, 320);
            this.BackColor       = BgColor;
            this.TopMost         = true;
            this.ShowInTaskbar   = false;
            this.DoubleBuffered  = true;
            this.Opacity         = 0;

            int r = 16;
            var gp = new GraphicsPath();
            gp.AddArc(0, 0, r * 2, r * 2, 180, 90);
            gp.AddArc(Width - r * 2, 0, r * 2, r * 2, 270, 90);
            gp.AddArc(Width - r * 2, Height - r * 2, r * 2, r * 2, 0, 90);
            gp.AddArc(0, Height - r * 2, r * 2, r * 2, 90, 90);
            gp.CloseFigure();
            this.Region = new Region(gp);

            animTimer.Interval = 16;
            animTimer.Tick    += OnAnimTick;
            animTimer.Start();

            closeTimer.Interval = 1000;
            closeTimer.Tick    += (s, e) => { closeTimer.Stop(); StartFadeOut(); };

            fadeTimer.Interval = 16;
            fadeTimer.Tick    += OnFadeTick;
        }

        private void StartFadeOut()
        {
            if (isClosing) return;
            isClosing = true;
            animTimer.Stop();
            fadeTimer.Start();
        }

        private void OnFadeTick(object? sender, EventArgs e)
        {
            if (IsDisposed) { fadeTimer.Stop(); return; }
            this.Opacity -= 0.07;
            if (this.Opacity <= 0)
            {
                fadeTimer.Stop();
                if (!IsDisposed) this.Close();
            }
        }

        private void OnAnimTick(object? sender, EventArgs e)
        {
            if (IsDisposed || isClosing) { animTimer.Stop(); return; }

            animStep++;

            if (this.Opacity < 1.0)
                this.Opacity = Math.Min(1.0, this.Opacity + 0.06);

            if (ringScale < 1.0f)
                ringScale = Math.Min(1.0f, ringScale + 0.035f);

            if (animStep > 18)
                logoAlpha = Math.Min(1.0f, logoAlpha + 0.07f);

            if (animStep > 28)
                progress = Math.Min(1.0f, progress + 0.016f);

            if (animStep > 55)
                byLineAlpha = Math.Min(1.0f, byLineAlpha + 0.05f);

            if (progress >= 1.0f && !closeTimer.Enabled && !isClosing)
                closeTimer.Start();

            if (!IsDisposed) this.Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            if (IsDisposed) return;

            Graphics g = e.Graphics;
            g.SmoothingMode     = SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

            int cx = Width  / 2;
            int cy = Height / 2 - 10;

            g.Clear(BgColor);

            using (var pen = new Pen(BorderColor, 1))
                g.DrawRectangle(pen, 0, 0, Width - 1, Height - 1);

            DrawRing(g, cx, cy, (int)(100 * ringScale), 18);
            DrawRing(g, cx, cy, (int)(155 * ringScale), 10);
            DrawRing(g, cx, cy, (int)(210 * ringScale),  5);

            int lai = (int)(logoAlpha * 255);
            if (lai > 0)
            {
                int sq  = 15;
                int gap = 5;
                int tot = sq * 2 + gap;
                int ix  = cx - tot / 2;
                int iy  = cy - 68;

                using (var b = new SolidBrush(Color.FromArgb(lai, OrangeColor)))
                    FillRounded(g, b, ix, iy, sq, sq, 3);
                using (var b = new SolidBrush(Color.FromArgb(lai, YellowColor)))
                    FillRounded(g, b, ix + sq + gap, iy, sq, sq, 3);
                using (var b = new SolidBrush(Color.FromArgb(lai, YellowColor)))
                    FillRounded(g, b, ix, iy + sq + gap, sq, sq, 3);
                using (var b = new SolidBrush(Color.FromArgb((int)(lai * 0.45f), OrangeColor)))
                    FillRounded(g, b, ix + sq + gap, iy + sq + gap, sq, sq, 3);

                using (var fBig = new Font("Segoe UI", 38, FontStyle.Bold, GraphicsUnit.Pixel))
                using (var sf   = new StringFormat(StringFormat.GenericTypographic))
                {
                    sf.FormatFlags = StringFormatFlags.NoWrap;
                    sf.Trimming    = StringTrimming.None;

                    SizeF icoSz = g.MeasureString("ICO",   fBig, int.MaxValue, sf);
                    SizeF clrSz = g.MeasureString("CLEAR", fBig, int.MaxValue, sf);
                    float totalW = icoSz.Width + clrSz.Width;
                    float tx     = cx - totalW / 2;
                    float ty     = cy - 22;

                    using (var wb = new SolidBrush(Color.FromArgb(lai, WhiteColor)))
                        g.DrawString("ICO",   fBig, wb, tx, ty, sf);
                    using (var ob = new SolidBrush(Color.FromArgb(lai, OrangeColor)))
                        g.DrawString("CLEAR", fBig, ob, tx + icoSz.Width, ty, sf);
                }

                using (var fSub = new Font("Segoe UI", 11, FontStyle.Regular, GraphicsUnit.Pixel))
                using (var sb   = new SolidBrush(Color.FromArgb((int)(lai * 0.55f), MutedColor)))
                using (var sf   = new StringFormat { Alignment = StringAlignment.Center })
                {
                    g.DrawString("DESKTOP ICON MANAGER", fSub, sb,
                        new RectangleF(0, cy + 22, Width, 20), sf);
                }
            }

            int barW = 200;
            int barH = 3;
            int barX = cx - barW / 2;
            int barY = cy + 56;

            using (var tb = new SolidBrush(BorderColor))
                FillRounded(g, tb, barX, barY, barW, barH, 2);

            if (progress > 0)
            {
                int fw = (int)(barW * progress);
                if (fw > 2)
                    using (var lb = new LinearGradientBrush(
                        new Rectangle(barX, barY, fw, barH),
                        OrangeColor, YellowColor, LinearGradientMode.Horizontal))
                    {
                        FillRounded(g, lb, barX, barY, fw, barH, 2);
                    }
            }

            int bai = (int)(byLineAlpha * 255);
            if (bai > 0)
            {
                using (var fBy = new Font("Segoe UI", 11, FontStyle.Regular, GraphicsUnit.Pixel))
                using (var sf  = new StringFormat(StringFormat.GenericTypographic))
                {
                    sf.FormatFlags = StringFormatFlags.NoWrap;
                    SizeF bySz   = g.MeasureString("by ",     fBy, int.MaxValue, sf);
                    SizeF nameSz = g.MeasureString("zechren", fBy, int.MaxValue, sf);
                    float bx     = cx - (bySz.Width + nameSz.Width) / 2;
                    float byY    = Height - 32f;

                    using (var mb = new SolidBrush(Color.FromArgb(bai, MutedColor)))
                        g.DrawString("by ",     fBy, mb, bx,              byY, sf);
                    using (var ob = new SolidBrush(Color.FromArgb(bai, OrangeColor)))
                        g.DrawString("zechren", fBy, ob, bx + bySz.Width, byY, sf);
                }
            }
        }

        private void DrawRing(Graphics g, int cx, int cy, int radius, int alpha)
        {
            if (radius < 5 || alpha <= 0) return;
            int a = (int)(alpha * ringScale);
            using (var pen = new Pen(Color.FromArgb(Math.Clamp(a, 0, 255), OrangeColor), 1))
                g.DrawEllipse(pen, cx - radius, cy - radius, radius * 2, radius * 2);
        }

        private static void FillRounded(Graphics g, Brush b, float x, float y, float w, float h, float r)
        {
            if (w <= 0 || h <= 0) return;
            float d = Math.Min(r * 2, Math.Min(w, h));
            var path = new GraphicsPath();
            path.AddArc(x,         y,         d, d, 180, 90);
            path.AddArc(x + w - d, y,         d, d, 270, 90);
            path.AddArc(x + w - d, y + h - d, d, d,   0, 90);
            path.AddArc(x,         y + h - d, d, d,  90, 90);
            path.CloseFigure();
            g.FillPath(b, path);
        }

        private static void FillRounded(Graphics g, Brush b, int x, int y, int w, int h, int r)
            => FillRounded(g, b, (float)x, (float)y, (float)w, (float)h, (float)r);

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                animTimer?.Stop();  animTimer?.Dispose();
                closeTimer?.Stop(); closeTimer?.Dispose();
                fadeTimer?.Stop();  fadeTimer?.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
