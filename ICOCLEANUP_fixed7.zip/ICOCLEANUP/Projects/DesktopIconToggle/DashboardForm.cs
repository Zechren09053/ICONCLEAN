using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.Win32;

namespace DesktopIconToggle
{
    public class DashboardForm : Form
    {
        static readonly Color BG         = Color.FromArgb(15, 15, 18);
        static readonly Color SidebarBg  = Color.FromArgb(20, 20, 24);
        static readonly Color CardBg     = Color.FromArgb(26, 26, 31);
        static readonly Color CardBorder = Color.FromArgb(45, 45, 52);
        static readonly Color Orange     = Color.FromArgb(230, 100, 30);
        static readonly Color OrangeDim  = Color.FromArgb(80, 38, 10);
        static readonly Color Green      = Color.FromArgb(34, 197, 94);
        static readonly Color TextHi     = Color.FromArgb(242, 242, 242);
        static readonly Color TextMid    = Color.FromArgb(160, 160, 170);
        static readonly Color TextDim    = Color.FromArgb(100, 100, 110);

        const int SW = 190;
        const int FW = 720, FH = 560;

        private readonly Settings _s;
        private readonly Action   _save;
        private readonly Action   _showIcons;
        private readonly Action   _hideIcons;
        private readonly Action   _showTaskbar;
        private readonly Action   _hideTaskbar;
        private readonly Action   _startAutoHide;
        private readonly Action   _stopAutoHide;
        private readonly Action   _exitApp;

        record LogEntry(string Time, string Msg, string Status);
        private readonly List<LogEntry> _log = new();
        private readonly int[] _dayToggles = new int[7];

        private Panel _sidebar   = null!;
        private Panel _content   = null!;
        private Panel _pgDash    = null!;
        private Panel _pgMon     = null!;
        private Panel _pgLog     = null!;
        private Panel _pgSet     = null!;
        private Panel _pgHot     = null!;
        private Panel _pgAbout   = null!;

        private DashToggle _ahToggle    = null!;
        private TrackBar   _delaySlider = null!;
        private TrackBar   _opacSlider  = null!;
        private Label      _delayLbl    = null!;
        private Label      _opacLbl     = null!;
        private Panel      _chartPnl    = null!;
        private ListBox    _miniLog     = null!;
        private Button     _toggleBtn   = null!;
        private bool       _iconsHidden = false;
        private Label      _gpuUsageLbl  = null!;
        private Label      _gpuBarFill   = null!;
        private Label      _gpuVramLbl   = null!;
        private Label      _gpuTempLbl   = null!;
        private readonly System.Windows.Forms.Timer _gpuTimer = new() { Interval = 1500 };

        private string _activePage = "Dashboard";
        private readonly System.Windows.Forms.Timer _tick = new() { Interval = 2000 };

        public DashboardForm(Settings s, Action save, Action showI, Action hideI,
                             Action showT, Action hideT, Func<bool> _,
                             Action? startAutoHide = null, Action? stopAutoHide = null,
                             Action? exitApp = null)
        {
            _s = s; _save = save;
            _showIcons = showI; _hideIcons = hideI;
            _showTaskbar = showT; _hideTaskbar = hideT;
            _startAutoHide = startAutoHide ?? (() => {});
            _stopAutoHide  = stopAutoHide  ?? (() => {});
            _exitApp       = exitApp       ?? (() => System.Windows.Forms.Application.Exit());
            SeedData();
            Build();
        }

        void SeedData()
        {
            var n = DateTime.Now;
            _log.Add(new(n.AddMinutes(-1).ToString("HH:mm:ss"),  "App started",    "OK"));
            _log.Add(new(n.AddSeconds(-40).ToString("HH:mm:ss"), "Icons shown",    "OK"));
            _log.Add(new(n.AddSeconds(-20).ToString("HH:mm:ss"), "Auto mode off",  "—"));
            _log.Add(new(n.AddSeconds(-8).ToString("HH:mm:ss"),  "Icons hidden",   "HIDE"));
            _log.Add(new(n.AddSeconds(-2).ToString("HH:mm:ss"),  "Session started","OK"));
            var rng = new Random(42);
            for (int i = 0; i < 7; i++) _dayToggles[i] = rng.Next(1, 6);
            _dayToggles[TodayIdx()] = 8;
        }

        static int TodayIdx() => ((int)DateTime.Today.DayOfWeek + 6) % 7;

        void AddLog(string msg, string status)
        {
            _log.Insert(0, new(DateTime.Now.ToString("HH:mm:ss"), msg, status));
            if (_log.Count > 80) _log.RemoveAt(_log.Count - 1);
            RefreshMiniLog();
            _chartPnl?.Invalidate();
        }

        [DllImport("user32.dll")] static extern bool ReleaseCapture();
        [DllImport("user32.dll")] static extern int SendMessage(IntPtr h, int m, int w, int l);
        [DllImport("gdi32.dll")]  static extern IntPtr CreateRoundRectRgn(int x1, int y1, int x2, int y2, int cx, int cy);
        [DllImport("user32.dll")] static extern int SetWindowRgn(IntPtr hWnd, IntPtr hRgn, bool bRedraw);

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            ApplyRoundedCorners();
        }

        protected override void OnSizeChanged(EventArgs e)
        {
            base.OnSizeChanged(e);
            if (IsHandleCreated) ApplyRoundedCorners();
        }

        void ApplyRoundedCorners()
        {
            IntPtr rgn = CreateRoundRectRgn(0, 0, Width + 1, Height + 1, 16, 16);
            SetWindowRgn(Handle, rgn, true);
        }

        void Build()
        {
            Text = "ICOCLEAR — Icon Manager";
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = true;
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(FW, FH);
            BackColor = BG;
            DoubleBuffered = true;
            ShowInTaskbar = true;
            MouseDown += (_, e) =>
            {
                if (e.Button == MouseButtons.Left) { ReleaseCapture(); SendMessage(Handle, 0xA1, 0x2, 0); }
            };

            BuildSidebar();
            _content = MkPanel(SW, 0, FW - SW, FH, BG);
            Controls.Add(_content);

            BuildPageDash();
            BuildPageMonitors();
            BuildPageLog();
            BuildPageSettings();
            BuildPageHotkeys();
            BuildPageAbout();
            ShowPage("Dashboard");
            _tick.Start();
            _gpuTimer.Tick += (_, __) => RefreshGpu();
            _gpuTimer.Start();
        }

        // ── Sidebar ──────────────────────────────────────────────────────────
        void BuildSidebar()
        {
            _sidebar = MkPanel(0, 0, SW, FH, SidebarBg);
            Controls.Add(_sidebar);

            _sidebar.Controls.Add(MkLbl("ICOCLEAR",     18, 18, 13f, FontStyle.Bold,    Orange));
            _sidebar.Controls.Add(MkLbl("ICON MANAGER", 20, 42,  7f, FontStyle.Regular, TextDim));
            _sidebar.Controls.Add(HLine(0, 64, SW));

            _sidebar.Controls.Add(MkLbl("MAIN", 18, 74, 7f, FontStyle.Bold, TextDim));
            NavItem("Dashboard",    "⊞", 90,  true);
            NavItem("Monitors",     "🖥", 118);
            NavItem("Activity log", "≡",  146);
            _sidebar.Controls.Add(MkLbl("APP", 18, 182, 7f, FontStyle.Bold, TextDim));
            NavItem("Settings", "⚙", 198);
            NavItem("Hotkeys",  "⌨", 226);
            NavItem("About",    "ℹ",  254);

            var us = MkPanel(0, FH - 52, SW, 52, Color.FromArgb(18, 18, 22));
            var av = new Label
            {
                Text = "Z", Font = new Font("Segoe UI", 11f, FontStyle.Bold),
                ForeColor = Color.White, BackColor = Orange,
                Size = new Size(32, 32), Location = new Point(14, 10),
                TextAlign = ContentAlignment.MiddleCenter
            };
            MkEllipse(av);
            us.Controls.Add(av);
            us.Controls.Add(MkLbl("Zechren", 52, 10, 9f,  FontStyle.Bold,    TextHi));
            us.Controls.Add(MkLbl("v1.0.0",  54, 28, 7f,  FontStyle.Regular, TextDim));
            _sidebar.Controls.Add(us);
        }

        void NavItem(string page, string icon, int y, bool active = false)
        {
            var l = new Label
            {
                Text = $"  {icon}  {page}", Font = new Font("Segoe UI", 9.5f),
                ForeColor = active ? TextHi : TextMid,
                BackColor = active ? Color.FromArgb(40, 40, 48) : Color.Transparent,
                Location = new Point(0, y), Size = new Size(SW, 26),
                TextAlign = ContentAlignment.MiddleLeft, Cursor = Cursors.Hand, Tag = page
            };
            l.MouseEnter += (_, __) => { if ((string)l.Tag! != _activePage) l.BackColor = Color.FromArgb(30, 30, 38); };
            l.MouseLeave += (_, __) => { if ((string)l.Tag! != _activePage) l.BackColor = Color.Transparent; };
            l.Click      += (_, __) => ShowPage((string)l.Tag!);
            _sidebar.Controls.Add(l);
        }

        void ShowPage(string page)
        {
            _activePage = page;
            foreach (Control c in _sidebar.Controls)
                if (c is Label l && l.Tag is string t)
                {
                    l.ForeColor = t == page ? TextHi : TextMid;
                    l.BackColor = t == page ? Color.FromArgb(40, 40, 48) : Color.Transparent;
                }
            _pgDash.Visible  = page == "Dashboard";
            _pgMon.Visible   = page == "Monitors";
            _pgLog.Visible   = page == "Activity log";
            _pgSet.Visible   = page == "Settings";
            _pgHot.Visible   = page == "Hotkeys";
            _pgAbout.Visible = page == "About";
        }

        // ── Dashboard ────────────────────────────────────────────────────────
        void BuildPageDash()
        {
            _pgDash = MkPanel(0, 0, FW - SW, FH, BG);
            _content.Controls.Add(_pgDash);

            int px = 18, py = 16, cw = FW - SW - px * 2;

            _pgDash.Controls.Add(MkLbl("Dashboard",             px, py,      14f, FontStyle.Bold,    TextHi));
            _pgDash.Controls.Add(MkLbl("Desktop icon controls", px, py + 22,  8.5f, FontStyle.Regular, TextDim));

            // Right-aligned header row: [● Running] [Primary] [—] [✕]
            // Work right-to-left so nothing overlaps
            int hRight = FW - SW - 14;          // right margin

            var xb = MkLbl("✕", hRight - 16, py + 4, 10f, FontStyle.Regular, TextMid);
            xb.Cursor = Cursors.Hand; xb.Click += (_, __) => { _exitApp(); };
            _pgDash.Controls.Add(xb);
            hRight -= 26;

            var mb = MkLbl("—", hRight - 16, py + 4, 10f, FontStyle.Regular, TextMid);
            mb.Cursor = Cursors.Hand; mb.Click += (_, __) => { WindowState = FormWindowState.Minimized; };
            _pgDash.Controls.Add(mb);
            hRight -= 28;

            var pill = MkPill("Primary", Orange, hRight - 52, py + 4);
            _pgDash.Controls.Add(pill);
            hRight -= 60;

            _pgDash.Controls.Add(MkLbl("Running", hRight - 52, py + 6, 8f, FontStyle.Regular, Green));
            var dot = new Label { Size = new Size(8, 8), Location = new Point(hRight - 64, py + 10), BackColor = Green };
            MkEllipse(dot);
            _pgDash.Controls.Add(dot);

            py += 52;

            // Desktop icons card
            var ic = MkCard(px, py, cw, 72);
            ic.Controls.Add(MkLbl("Desktop icons", 14, 10, 10f, FontStyle.Bold, TextHi));
            ic.Controls.Add(MkLbl("Show or hide all desktop icons and the taskbar", 14, 30, 8f, FontStyle.Regular, TextMid));
            _toggleBtn = MkBtn(_iconsHidden ? "Show desktop" : "Hide desktop",
                               _iconsHidden ? Color.FromArgb(22, 44, 22) : OrangeDim,
                               _iconsHidden ? Green : Orange);
            _toggleBtn.Location = new Point(ic.Width - 128, 18);
            _toggleBtn.Click += (_, __) =>
            {
                _iconsHidden = !_iconsHidden;
                if (_iconsHidden) { _hideIcons(); _hideTaskbar(); AddLog("Icons hidden", "HIDE"); }
                else              { _showIcons(); _showTaskbar(); AddLog("Icons shown",  "OK");   }
                _toggleBtn.Text      = _iconsHidden ? "Show desktop" : "Hide desktop";
                _toggleBtn.BackColor = _iconsHidden ? Color.FromArgb(22, 44, 22) : OrangeDim;
                _toggleBtn.ForeColor = _iconsHidden ? Green : Orange;
            };
            ic.Controls.Add(_toggleBtn);
            _pgDash.Controls.Add(ic);
            py += 82;

            _pgDash.Controls.Add(MkLbl("AUTO-HIDE", px, py, 7.5f, FontStyle.Bold, TextDim));
            py += 18;

            var ah = MkCard(px, py, cw, 132);
            ah.Controls.Add(MkLbl("Auto-hide mode", 14, 12, 10f, FontStyle.Bold, TextHi));
            ah.Controls.Add(MkLbl("Hides icons automatically after inactivity timeout", 14, 32, 8f, FontStyle.Regular, TextMid));

            _ahToggle = new DashToggle { Location = new Point(ah.Width - 70, 14), Checked = _s.AutoHideEnabled };
            _ahToggle.CheckedChanged += (_, __) =>
            {
                _s.AutoHideEnabled = _ahToggle.Checked;
                _save();
                if (_s.AutoHideEnabled) _startAutoHide();
                else                   _stopAutoHide();
                AddLog(_s.AutoHideEnabled ? "Auto mode on" : "Auto mode off", _s.AutoHideEnabled ? "OK" : "—");
                UpdateSliders();
            };
            ah.Controls.Add(_ahToggle);
            ah.Controls.Add(HLine(14, 56, ah.Width - 28));

            ah.Controls.Add(MkLbl("Hide delay", 14, 66, 8.5f, FontStyle.Regular, TextMid));
            _delayLbl = MkLbl($"{_s.AutoHideDelaySeconds}s", ah.Width - 40, 66, 8.5f, FontStyle.Bold, Orange);
            ah.Controls.Add(_delayLbl);
            _delaySlider = MkSlider(14, 84, ah.Width - 28, 1, 30, _s.AutoHideDelaySeconds);
            _delaySlider.ValueChanged += (_, __) => { _s.AutoHideDelaySeconds = _delaySlider.Value; _delayLbl.Text = $"{_delaySlider.Value}s"; _save(); };
            ah.Controls.Add(_delaySlider);

            ah.Controls.Add(MkLbl("Button opacity", 14, 102, 8.5f, FontStyle.Regular, TextMid));
            _opacLbl = MkLbl("90%", ah.Width - 44, 102, 8.5f, FontStyle.Bold, Orange);
            ah.Controls.Add(_opacLbl);
            _opacSlider = MkSlider(14, 118, ah.Width - 28, 10, 100, 90);
            _opacSlider.ValueChanged += (_, __) => _opacLbl.Text = $"{_opacSlider.Value}%";
            ah.Controls.Add(_opacSlider);

            _pgDash.Controls.Add(ah);
            UpdateSliders();
            py += 142;

            int colW = (cw - 10) / 2, rx = px + colW + 10;

            _pgDash.Controls.Add(MkLbl("ACTIVITY LOG",  px, py, 7.5f, FontStyle.Bold, TextDim));
            _pgDash.Controls.Add(MkPill("Live", Green, px + 106, py - 1));
            _pgDash.Controls.Add(MkLbl("GPU ACTIVITY",  rx, py, 7.5f, FontStyle.Bold, TextDim));
            py += 18;

            var logCard = MkCard(px, py, colW, 190);
            _miniLog = new FlatListBox
            {
                DrawMode = DrawMode.OwnerDrawFixed, BorderStyle = BorderStyle.None,
                BackColor = CardBg, ForeColor = TextHi, Font = new Font("Courier New", 7f),
                Dock = DockStyle.Fill, ItemHeight = 22, SelectionMode = SelectionMode.None
            };
            _miniLog.DrawItem += DrawLogItem;
            logCard.Controls.Add(_miniLog);
            _pgDash.Controls.Add(logCard);
            RefreshMiniLog();

            var qac = MkCard(rx, py, colW, 190);
            BuildGpuPanel(qac);
            _pgDash.Controls.Add(qac);
        }

        void BuildGpuPanel(Panel parent)
        {
            parent.Controls.Add(MkLbl("GPU", 12, 10, 8.5f, FontStyle.Bold, TextHi));
            parent.Controls.Add(MkLbl("Graphics adapter", 12, 28, 7.5f, FontStyle.Regular, TextMid));

            // Usage bar background
            var barBg = MkPanel(12, 52, parent.Width - 24, 8, Color.FromArgb(40, 40, 50));
            parent.Controls.Add(barBg);
            _gpuBarFill = new Label
            {
                Location = new Point(0, 0), Size = new Size(0, 8),
                BackColor = Orange, Text = ""
            };
            barBg.Controls.Add(_gpuBarFill);

            _gpuUsageLbl = MkLbl("-- %", parent.Width - 56, 10, 9f, FontStyle.Bold, Orange);
            parent.Controls.Add(_gpuUsageLbl);

            var sep = HLine(12, 70, parent.Width - 24);
            parent.Controls.Add(sep);

            // Stats rows
            parent.Controls.Add(MkLbl("VRAM Used",  12,  82, 7.5f, FontStyle.Regular, TextMid));
            _gpuVramLbl = MkLbl("-- MB",  parent.Width - 72,  82, 7.5f, FontStyle.Bold, TextHi);
            parent.Controls.Add(_gpuVramLbl);

            parent.Controls.Add(MkLbl("Temp",        12, 104, 7.5f, FontStyle.Regular, TextMid));
            _gpuTempLbl = MkLbl("-- °C", parent.Width - 72, 104, 7.5f, FontStyle.Bold, TextHi);
            parent.Controls.Add(_gpuTempLbl);

            parent.Controls.Add(MkLbl("Engine",      12, 126, 7.5f, FontStyle.Regular, TextMid));
            parent.Controls.Add(MkLbl("3D / Render", parent.Width - 82, 126, 7.5f, FontStyle.Bold, TextHi));

            parent.Controls.Add(HLine(12, 148, parent.Width - 24));
            parent.Controls.Add(MkLbl("Via WMI · updates every 1.5s", 12, 158, 6.5f, FontStyle.Regular, TextDim));

            RefreshGpu();
        }

        private float _lastGpuLoad = 0f;

        void RefreshGpu()
        {
            try
            {
                using var searcher = new System.Management.ManagementObjectSearcher(
                    "SELECT * FROM Win32_VideoController");
                foreach (System.Management.ManagementObject obj in searcher.Get())
                {
                    // GPU load via performance counter if available
                    float load = _lastGpuLoad;
                    try
                    {
                        using var pc = new System.Diagnostics.PerformanceCounter(
                            "GPU Engine", "Utilization Percentage", "_Total", true);
                        load = pc.NextValue();
                        System.Threading.Thread.Sleep(100);
                        load = pc.NextValue();
                        _lastGpuLoad = load;
                    }
                    catch { load = _lastGpuLoad; }

                    long adapterRam = 0;
                    try { adapterRam = Convert.ToInt64(obj["AdapterRAM"]) / (1024 * 1024); } catch { }

                    string temp = "--";
                    try
                    {
                        using var ts = new System.Management.ManagementObjectSearcher(
                            @"root\OpenHardwareMonitor", "SELECT * FROM Sensor WHERE SensorType='Temperature' AND Identifier LIKE '%gpu%'");
                        foreach (System.Management.ManagementObject t in ts.Get())
                        { temp = $"{Convert.ToSingle(t["Value"]):0}"; break; }
                    }
                    catch { }

                    if (_gpuUsageLbl == null || _gpuUsageLbl.IsDisposed) break;
                    _gpuUsageLbl.Text  = $"{load:0} %";
                    _gpuUsageLbl.ForeColor = load > 80 ? Color.FromArgb(220, 60, 60) : load > 50 ? Orange : Green;

                    if (_gpuBarFill?.Parent != null)
                    {
                        int maxW = _gpuBarFill.Parent.Width;
                        _gpuBarFill.Width = (int)(load / 100f * maxW);
                        _gpuBarFill.BackColor = _gpuUsageLbl.ForeColor;
                    }

                    if (adapterRam > 0) _gpuVramLbl.Text = $"{adapterRam} MB";
                    _gpuTempLbl.Text = temp != "--" ? $"{temp} °C" : "N/A";
                    break;
                }
            }
            catch { }
        }

        void QAction(Panel parent, string icon, string title, string sub, int y, Action click)
        {
            var row = new Panel
            {
                Location = new Point(0, y), Size = new Size(parent.Width, 36),
                BackColor = Color.Transparent, Cursor = Cursors.Hand
            };
            row.MouseEnter += (_, __) => row.BackColor = Color.FromArgb(35, 35, 44);
            row.MouseLeave += (_, __) => row.BackColor = Color.Transparent;
            row.Click += (_, __) => click();

            var iconL  = MkLbl(icon,  10, 8,  11f, FontStyle.Regular, Orange);
            var titleL = MkLbl(title, 36, 4,   9f, FontStyle.Bold,    TextHi);
            var subL   = MkLbl(sub,   36, 20, 7f,  FontStyle.Regular, TextMid);
            var arr    = MkLbl("↗", parent.Width - 22, 8, 8f, FontStyle.Regular, TextDim);

            iconL.Parent = row; titleL.Parent = row; subL.Parent = row; arr.Parent = row;
            parent.Controls.Add(row);
        }

        // ── Monitors ─────────────────────────────────────────────────────────
        void BuildPageMonitors()
        {
            _pgMon = MkPanel(0, 0, FW - SW, FH, BG);
            _pgMon.Visible = false;
            _content.Controls.Add(_pgMon);
            RefreshMonitors();
        }

        void RefreshMonitors()
        {
            _pgMon.Controls.Clear();
            _pgMon.Controls.Add(PageHdr("Monitors", "Select target display for the toggle button"));
            int py = 70, px = 18, cw = FW - SW - px * 2;
            foreach (var (sc, i) in System.Linq.Enumerable.Select(Screen.AllScreens, (s, i) => (s, i)))
            {
                int idx = i;
                var mc = MkCard(px, py, cw, 64);
                mc.Controls.Add(MkLbl($"Monitor {i + 1}{(sc.Primary ? " (Primary)" : "")}", 14, 10, 10f, FontStyle.Bold, TextHi));
                mc.Controls.Add(MkLbl($"{sc.Bounds.Width}×{sc.Bounds.Height}  |  {sc.DeviceName}", 14, 30, 8f, FontStyle.Regular, TextMid));
                bool sel = _s.MonitorId == sc.DeviceName || (string.IsNullOrEmpty(_s.MonitorId) && sc.Primary);
                var selBtn = MkBtn(sel ? "Selected" : "Select", sel ? OrangeDim : Color.FromArgb(35, 35, 42), sel ? Orange : TextMid);
                selBtn.Location = new Point(mc.Width - 114, 14);
                selBtn.Click += (_, __) => { _s.MonitorId = sc.DeviceName; _save(); RefreshMonitors(); };
                mc.Controls.Add(selBtn);
                _pgMon.Controls.Add(mc);
                py += 74;
            }
        }

        // ── Activity Log page ────────────────────────────────────────────────
        void BuildPageLog()
        {
            _pgLog = MkPanel(0, 0, FW - SW, FH, BG);
            _pgLog.Visible = false;
            _content.Controls.Add(_pgLog);
            _pgLog.Controls.Add(PageHdr("Activity Log", "Full session event history"));

            var bigList = new FlatListBox
            {
                DrawMode = DrawMode.OwnerDrawFixed, BorderStyle = BorderStyle.None,
                BackColor = CardBg, ForeColor = TextHi, Font = new Font("Courier New", 8f),
                Size = new Size(FW - SW - 36, FH - 98), Location = new Point(18, 80),
                ItemHeight = 24, SelectionMode = SelectionMode.None
            };
            bigList.DrawItem += DrawLogItem;
            foreach (var e in _log) bigList.Items.Add(e);
            _pgLog.Controls.Add(bigList);
        }

        // ── Settings ─────────────────────────────────────────────────────────
        void BuildPageSettings()
        {
            _pgSet = MkPanel(0, 0, FW - SW, FH, BG);
            _pgSet.Visible = false;
            _content.Controls.Add(_pgSet);
            _pgSet.Controls.Add(PageHdr("Settings", "Configure ICOCLEAR behaviour"));

            int py = 70, px = 18, cw = FW - SW - px * 2;

            var sc = MkCard(px, py, cw, 64);
            sc.Controls.Add(MkLbl("Launch on Windows startup", 14, 10, 10f, FontStyle.Bold, TextHi));
            sc.Controls.Add(MkLbl("Register autostart in the Windows registry", 14, 30, 8f, FontStyle.Regular, TextMid));
            var st = new DashToggle { Location = new Point(sc.Width - 70, 16), Checked = _s.AutoStart };
            st.CheckedChanged += (_, __) => { _s.AutoStart = st.Checked; _save(); UpdateStartup(st.Checked); };
            sc.Controls.Add(st);
            _pgSet.Controls.Add(sc);
            py += 74;

            var dc = MkCard(px, py, cw, 64);
            dc.Controls.Add(MkLbl("Dock side", 14, 10, 10f, FontStyle.Bold, TextHi));
            dc.Controls.Add(MkLbl("Edge where the toggle button appears", 14, 30, 8f, FontStyle.Regular, TextMid));
            var combo = new ComboBox
            {
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Color.FromArgb(35, 35, 45), ForeColor = TextHi,
                Font = new Font("Segoe UI", 9f), Location = new Point(dc.Width - 134, 18), Size = new Size(120, 28)
            };
            combo.Items.AddRange(new object[] { "Left edge", "Top edge" });
            combo.SelectedIndex = Math.Clamp(_s.DockSide, 0, 1);
            combo.SelectedIndexChanged += (_, __) => { _s.DockSide = combo.SelectedIndex; _save(); };
            dc.Controls.Add(combo);
            _pgSet.Controls.Add(dc);
        }

        void UpdateStartup(bool enable)
        {
            try
            {
                using var key = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", true);
                if (enable) key?.SetValue("ICOCLEAR", Application.ExecutablePath);
                else key?.DeleteValue("ICOCLEAR", false);
            }
            catch { }
        }

        // ── Hotkeys ──────────────────────────────────────────────────────────
        void BuildPageHotkeys()
        {
            _pgHot = MkPanel(0, 0, FW - SW, FH, BG);
            _pgHot.Visible = false;
            _content.Controls.Add(_pgHot);
            _pgHot.Controls.Add(PageHdr("Hotkeys", "Global keyboard shortcuts"));

            int py = 70, px = 18, cw = FW - SW - px * 2;
            (string action, string key)[] hk =
            {
                ("Toggle desktop icons",  "Ctrl + Shift + H"),
                ("Toggle auto-hide mode", "Ctrl + Shift + A"),
                ("Show dashboard",        "Ctrl + Shift + D")
            };
            foreach (var (action, key) in hk)
            {
                var hc = MkCard(px, py, cw, 62);
                hc.Controls.Add(MkLbl(action, 14, 12, 10f, FontStyle.Bold, TextHi));
                hc.Controls.Add(MkLbl("Global shortcut", 14, 32, 8f, FontStyle.Regular, TextMid));
                hc.Controls.Add(MkPill(key, Color.FromArgb(50, 50, 60), hc.Width - 238, 14));
                var eb = MkBtn("Rebind", Color.FromArgb(35, 35, 42), TextMid);
                eb.Location = new Point(hc.Width - 84, 14);
                hc.Controls.Add(eb);
                _pgHot.Controls.Add(hc);
                py += 72;
            }
        }

        // ── About ────────────────────────────────────────────────────────────
        void BuildPageAbout()
        {
            _pgAbout = MkPanel(0, 0, FW - SW, FH, BG);
            _pgAbout.Visible = false;
            _content.Controls.Add(_pgAbout);
            _pgAbout.Controls.Add(PageHdr("About", "ICOCLEAR Icon Manager"));

            int px = 18, cw = FW - SW - px * 2;
            var ac = MkCard(px, 80, cw, 120);
            ac.Controls.Add(MkLbl("ICOCLEAR", 14, 14, 14f, FontStyle.Bold, Orange));
            ac.Controls.Add(MkLbl("Desktop Icon Manager", 14, 42, 9f, FontStyle.Regular, TextMid));
            ac.Controls.Add(MkLbl("Version 1.0.0  |  C# WinForms  |  .NET 9", 14, 62, 8f, FontStyle.Regular, TextDim));
            ac.Controls.Add(MkLbl("A lightweight utility to manage Windows desktop icons.", 14, 82, 8.5f, FontStyle.Regular, TextMid));
            ac.Controls.Add(MkLbl("© 2025 Zechren · SofiTech Capstone Team", 14, 100, 8f, FontStyle.Regular, TextDim));
            _pgAbout.Controls.Add(ac);
        }

        // ── Log drawing ──────────────────────────────────────────────────────
        void RefreshMiniLog()
        {
            if (_miniLog == null) return;
            _miniLog.Items.Clear();
            foreach (var e in _log) _miniLog.Items.Add(e);
        }

        void DrawLogItem(object? sender, DrawItemEventArgs e)
        {
            if (e.Index < 0 || sender is not ListBox lb) return;
            var entry = (LogEntry)lb.Items[e.Index];
            var g = e.Graphics;
            g.FillRectangle(new SolidBrush(e.Index % 2 == 0 ? CardBg : Color.FromArgb(30, 30, 37)), e.Bounds);
            using var tf = new Font("Courier New", 7.5f);
            g.DrawString(entry.Time, tf, new SolidBrush(TextDim), e.Bounds.X + 4,  e.Bounds.Y + 4);
            g.DrawString(entry.Msg,  tf, new SolidBrush(TextHi),  e.Bounds.X + 72, e.Bounds.Y + 4);
            Color bc = entry.Status == "OK"   ? Green  :
                       entry.Status == "HIDE" ? Orange :
                       entry.Status == "ERR"  ? Color.FromArgb(220, 60, 60) : TextDim;
            if (entry.Status != "—")
            {
                var rect = new Rectangle(e.Bounds.Right - 48, e.Bounds.Y + 3, 40, 15);
                g.FillRectangle(new SolidBrush(Color.FromArgb(50, bc)), rect);
                g.DrawString(entry.Status, new Font("Segoe UI", 6.5f, FontStyle.Bold), new SolidBrush(bc), rect.X + 4, rect.Y + 2);
            }
            else g.DrawString("—", tf, new SolidBrush(TextDim), e.Bounds.Right - 24, e.Bounds.Y + 4);
        }

        void UpdateSliders()
        {
            bool en = _s.AutoHideEnabled;
            _delaySlider.Enabled  = en;
            _opacSlider.Enabled   = en;
            _delayLbl.ForeColor   = en ? Orange : TextDim;
            _opacLbl.ForeColor    = en ? Orange : TextDim;
        }

        // ── Factory helpers ───────────────────────────────────────────────────
        static Panel MkPanel(int x, int y, int w, int h, Color bg)
            => new Panel { Location = new Point(x, y), Size = new Size(w, h), BackColor = bg };

        Panel MkCard(int x, int y, int w, int h)
        {
            var p = MkPanel(x, y, w, h, CardBg);
            p.Paint += (_, e) =>
            {
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                using var pen = new Pen(CardBorder, 1);
                RoundRect(e.Graphics, pen, new Rectangle(0, 0, p.Width - 1, p.Height - 1), 8);
            };
            return p;
        }

        static Label MkLbl(string text, int x, int y, float size, FontStyle style, Color fg)
            => new Label
            {
                Text = text, Font = new Font("Segoe UI", size, style),
                ForeColor = fg, BackColor = Color.Transparent,
                Location = new Point(x, y), AutoSize = true
            };

        static Label MkPill(string text, Color col, int x, int y)
            => new Label
            {
                Text = text, Font = new Font("Segoe UI", 7.5f, FontStyle.Bold),
                ForeColor = col, BackColor = Color.FromArgb(50, col.R, col.G, col.B),
                Location = new Point(x, y), AutoSize = true,
                Padding = new Padding(6, 2, 6, 2), TextAlign = ContentAlignment.MiddleCenter
            };

        static Button MkBtn(string text, Color bg, Color fg)
            => new Button
            {
                Text = text, Font = new Font("Segoe UI", 8.5f, FontStyle.Bold),
                ForeColor = fg, BackColor = bg, FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Size = new Size(108, 34), Cursor = Cursors.Hand
            };

        static TrackBar MkSlider(int x, int y, int w, int min, int max, int val)
            => new TrackBar
            {
                Location = new Point(x, y), Size = new Size(w, 20),
                Minimum = min, Maximum = max, Value = Math.Clamp(val, min, max),
                TickStyle = TickStyle.None, BackColor = Color.FromArgb(26, 26, 31)
            };

        static Panel HLine(int x, int y, int w)
            => new Panel { Location = new Point(x, y), Size = new Size(w, 1), BackColor = Color.FromArgb(45, 45, 52) };

        Control PageHdr(string title, string sub)
        {
            var p = MkPanel(0, 0, FW - SW, 62, BG);
            p.Controls.Add(MkLbl(title, 18, 14, 14f, FontStyle.Bold,    TextHi));
            p.Controls.Add(MkLbl(sub,   18, 38, 8.5f, FontStyle.Regular, TextDim));
            var mb2 = MkLbl("—", FW - SW - 56, 16, 10f, FontStyle.Regular, TextMid);
            mb2.Cursor = Cursors.Hand; mb2.Click += (_, __) => { WindowState = FormWindowState.Minimized; };
            p.Controls.Add(mb2);
            var xb = MkLbl("✕", FW - SW - 28, 16, 10f, FontStyle.Regular, TextMid);
            xb.Cursor = Cursors.Hand; xb.Click += (_, __) => { _exitApp(); };
            p.Controls.Add(xb);
            return p;
        }

        static void MkEllipse(Control c)
        {
            var gp = new GraphicsPath();
            gp.AddEllipse(0, 0, c.Width, c.Height);
            c.Region = new Region(gp);
        }

        static void RoundRect(Graphics g, Pen pen, Rectangle r, int rad)
        {
            int d = rad * 2;
            g.DrawArc(pen, r.X,         r.Y,          d, d, 180, 90);
            g.DrawArc(pen, r.Right - d, r.Y,          d, d, 270, 90);
            g.DrawArc(pen, r.Right - d, r.Bottom - d, d, d, 0,   90);
            g.DrawArc(pen, r.X,         r.Bottom - d, d, d, 90,  90);
            g.DrawLine(pen, r.X + rad,     r.Y,       r.Right - rad, r.Y);
            g.DrawLine(pen, r.Right,    r.Y + rad,    r.Right,       r.Bottom - rad);
            g.DrawLine(pen, r.X + rad,     r.Bottom,  r.Right - rad, r.Bottom);
            g.DrawLine(pen, r.X,        r.Y + rad,    r.X,           r.Bottom - rad);
        }

        protected override void OnFormClosed(FormClosedEventArgs e) { _tick.Stop(); _gpuTimer.Stop(); base.OnFormClosed(e); }
    }

    // ══════════════════════════════════════════════════════════════════════════
    //  DashToggle
    // ══════════════════════════════════════════════════════════════════════════
    public class DashToggle : Control
    {
        private bool _checked;

        [DefaultValue(false)]
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public bool Checked
        {
            get => _checked;
            set { _checked = value; Invalidate(); }
        }
        public event EventHandler? CheckedChanged;

        static readonly Color OnColor  = Color.FromArgb(230, 100, 30);
        static readonly Color OffColor = Color.FromArgb(60, 60, 70);

        public DashToggle()
        {
            Size = new Size(52, 26);
            Cursor = Cursors.Hand;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.ResizeRedraw | ControlStyles.OptimizedDoubleBuffer, true);
        }

        protected override void OnClick(EventArgs e)
        {
            _checked = !_checked;
            Invalidate();
            CheckedChanged?.Invoke(this, EventArgs.Empty);
            base.OnClick(e);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.Clear(Parent?.BackColor ?? Color.FromArgb(26, 26, 31));
            FillRR(g, new SolidBrush(_checked ? OnColor : OffColor),
                   new Rectangle(0, 0, Width - 1, Height - 1), Height / 2);
            int ts = Height - 6, tx = _checked ? Width - ts - 3 : 3;
            g.FillEllipse(Brushes.White, tx, 3, ts, ts);
            using var f = new Font("Segoe UI", 6.5f, FontStyle.Bold);
            g.DrawString(_checked ? "ON" : "OFF", f, Brushes.White, _checked ? 5 : tx + ts + 2, 7);
        }

        static void FillRR(Graphics g, Brush br, Rectangle r, int rad)
        {
            using var gp = new GraphicsPath();
            int d = rad * 2;
            gp.AddArc(r.X,         r.Y,          d, d, 180, 90);
            gp.AddArc(r.Right - d, r.Y,          d, d, 270, 90);
            gp.AddArc(r.Right - d, r.Bottom - d, d, d, 0,   90);
            gp.AddArc(r.X,         r.Bottom - d, d, d, 90,  90);
            gp.CloseFigure();
            g.FillPath(br, gp);
        }
    }
    // ══════════════════════════════════════════════════════════════════════════
    //  FlatListBox — ListBox with custom dark scrollbar
    // ══════════════════════════════════════════════════════════════════════════
    internal class FlatListBox : ListBox
    {
        private const int SB_VERT = 1;
        private const int WM_NCPAINT = 0x85;
        private const int WM_PAINT   = 0x0F;

        protected override void WndProc(ref Message m)
        {
            base.WndProc(ref m);
            if (m.Msg == WM_PAINT || m.Msg == WM_NCPAINT)
                DrawScrollBar();
        }

        private void DrawScrollBar()
        {
            int total = Items.Count;
            if (total == 0) return;
            int visible = ClientSize.Height / Math.Max(1, ItemHeight);
            if (total <= visible) return;

            using var g = CreateGraphics();
            int sbW = SystemInformation.VerticalScrollBarWidth;
            var track = new Rectangle(ClientSize.Width - sbW, 0, sbW, ClientSize.Height);

            // Track background
            g.FillRectangle(new SolidBrush(Color.FromArgb(22, 22, 28)), track);

            // Thumb
            float thumbH = Math.Max(24, (float)visible / total * ClientSize.Height);
            float thumbY = (float)TopIndex / Math.Max(1, total - visible) * (ClientSize.Height - thumbH);
            var thumb = new RectangleF(track.X + 3, thumbY + 2, sbW - 6, thumbH - 4);
            using var gp = new System.Drawing.Drawing2D.GraphicsPath();
            int r = 3;
            gp.AddArc(thumb.X, thumb.Y, r * 2, r * 2, 180, 90);
            gp.AddArc(thumb.Right - r * 2, thumb.Y, r * 2, r * 2, 270, 90);
            gp.AddArc(thumb.Right - r * 2, thumb.Bottom - r * 2, r * 2, r * 2, 0, 90);
            gp.AddArc(thumb.X, thumb.Bottom - r * 2, r * 2, r * 2, 90, 90);
            gp.CloseFigure();
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            g.FillPath(new SolidBrush(Color.FromArgb(80, 80, 95)), gp);
        }
    }

}