using System;
using System.Threading;
using System.Windows.Forms;

namespace DesktopIconToggle
{
    internal class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.SetHighDpiMode(HighDpiMode.PerMonitorV2);

            // Show splash screen
            SplashScreen splash = new SplashScreen();
            splash.Show();
            splash.Refresh();

            // Keep splash running until it closes itself (~3.5s)
            while (splash.Visible)
            {
                Application.DoEvents();
                Thread.Sleep(10);
            }

            // Launch main app
            Application.Run(new ToggleButton());
        }
    }
}
